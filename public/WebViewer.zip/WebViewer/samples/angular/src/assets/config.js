$.extend(ReaderControl.config, { serverURL: null });

window.rotatePages = function() {
  readerControl.rotateCounterClockwise();
};