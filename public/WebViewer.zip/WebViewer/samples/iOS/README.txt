==========================
   WebViewer iOS Sample
==========================
This is a sample iOS mobile application that supports offline viewing of XOD files where the PDFTron WebViewer is loaded in a UIWebView.

Before you run the sample, please copy the entire folder WebViewer\lib\html5 to WebViewer\samples\iOS\WebviewDemo\html5.

Also copy GettingStarted.xod into the xod folder.